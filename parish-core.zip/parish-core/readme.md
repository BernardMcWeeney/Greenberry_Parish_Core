=== Parish Core ===
Contributors: greenberry
Tags: parish, catholic, church, mass times, events, liturgical
Requires at least: 6.5
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 2.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A comprehensive parish management system for Catholic parishes.

== Description ==

Parish Core provides a complete solution for managing your Catholic parish website.

**Dashboard Features:**

* Welcome banner with parish logo
* Today's Mass Times widget
* This Week's Mass Schedule (7-day grid with today highlighted)
* Today's Mass Readings (First Reading, Psalm, Gospel)
* Liturgical calendar panel (season, feast day, color)
* Content Overview with clickable stats and "Add" links
* Recent Newsletters sidebar widget
* Upcoming Events list
* Quick Actions (customizable)
* Resources links
* Developed by Greenberry footer

**About Parish Editor:**

* Parish identity (name, description, logo, banner)
* Contact information (address, phone, email, office hours)
* Diocese information with link
* Social media links (Facebook, YouTube, Livestream)
* Clergy & Staff management
* Dashboard Resources management
* Quick Actions customization

**Mass Times Scheduler:**

* Visual 7-day grid scheduler
* Support for multiple churches
* Recurring patterns (weekly, first/last of month)
* Livestream integration with URL
* Notes per mass
* Active/inactive toggle

**Events Calendar:**

* Month calendar view with navigation
* Click day to add event
* Click event to edit
* Event types (parish, sacrament, feast)
* Color-coded events
* Location and description fields

**Settings (Admin Only):**

* Feature toggles for all 15 modules
* Admin Color Scheme customization (8 color options)
* Reset colors to defaults
* Shortcode Reference with attributes

**Readings API Page:**

* API key configuration
* All 7 endpoints listed
* Individual Fetch buttons per endpoint
* Fetch All Readings button
* Shortcode reference

**Custom Post Types (12 total):**

* Death Notices, Baptism Notices, Wedding Notices
* Churches, Schools, Cemeteries
* Parish Groups, Newsletters, News
* Gallery, Reflections, Prayers

**Shortcodes with Attributes:**

* [parish_mass_times] - day, church_id, show_livestream, format (daily/weekly/simple)
* [parish_events] - limit, type, month, year, past
* [parish_reflection] - Latest reflection
* [parish_churches] - List all churches
* [parish_clergy] - Staff/clergy list
* [parish_contact] - Contact information
* [parish_prayers] - limit, orderby
* [daily_readings] - Today's readings
* [mass_reading_details] - Detailed readings
* [feast_day_details] - Feast day info
* [sunday_homily] - Sunday homily
* [saint_of_the_day] - Today's saint
* [next_sunday_reading] - Next Sunday

**Role-Based Access:**

* Editors: Dashboard, About Parish, Mass Times, Events, CPTs
* Admins: All above plus Settings, Readings API, Feature Toggles

== Installation ==

1. Upload `parish-core` folder to `/wp-content/plugins/`
2. Activate the plugin
3. Go to Parish > Settings to configure features and colors
4. Go to Parish > About Parish to set up parish information
5. Add churches first (needed for mass times/events)
6. Configure mass times and events
7. Use shortcodes in your pages

== Changelog ==

= 2.2.0 =
* Added Today's Mass Times widget to dashboard
* Added This Week's Mass Schedule grid to dashboard
* Added Mass Readings card (First Reading, Psalm, Gospel) to dashboard
* Moved Liturgical panel to sidebar
* Added Recent Newsletters widget to sidebar
* Made Content Overview stats clickable with Add links
* Added Admin Color Scheme customization (8 colors)
* Added dedicated Readings API page with Fetch buttons
* Added Shortcode Reference panel with all attributes
* Added Prayers custom post type
* Added shortcode filters (day, church_id, format, type, month, year)
* Added Greenberry footer branding
* Fixed quick action default icons
* Improved responsive design

= 2.0.0 =
* Complete rewrite with React admin interface
* New dashboard with widgets
* About Parish editor
* Mass Times scheduler
* Events Calendar
* Feature toggles
* Liturgical calendar integration

= 1.0.0 =
* Initial release

# Parish Core - Liturgy.day API Integration Update

## Overview

This update adds integration with the **liturgy.day API** and creates human-readable shortcodes for liturgical information and rosary mysteries.

## New Features

### 1. Liturgy.day API Integration

Three new endpoints from liturgy.day:
- `/day/{date}` - Liturgical information for a specific day
- `/week/{date}` - Liturgical information for the week
- `/rosary-days/{date}` - Rosary mystery schedule for the current season

### 2. New Shortcodes

#### Liturgical Information

| Shortcode | Description |
|-----------|-------------|
| `[liturgical_day]` | Display today's liturgical season, cycles, and rosary |
| `[liturgical_week]` | Display the week's liturgical info with rosary schedule |
| `[rosary_days]` | Show which days each rosary series is prayed |

#### Rosary Shortcodes (Human-Readable)

| Shortcode | Description |
|-----------|-------------|
| `[rosary_today]` | Today's rosary mystery with optional link |
| `[rosary_week]` | Weekly rosary schedule (table or list format) |
| `[rosary_series]` | Overview of all four rosary series with descriptions |
| `[rosary_mysteries]` | Display the actual 5 mysteries of each series |

### 3. Fixed Feast Day Colors

The `[feast_day_details]` shortcode now displays actual colored circles next to each feast day to indicate the liturgical color.

## Installation

### Step 1: Replace class-parish-readings.php

Replace your existing `includes/class-parish-readings.php` with the new version.

### Step 2: Update Shortcode Reference

Replace the `parish_core_get_shortcode_reference()` function in `parish-core.php` with the updated version from `shortcode-reference-update.php`.

### Step 3: Add Frontend CSS

Add the contents of `front-css-additions.css` to your `assets/css/front.css` file.

## Usage Examples

### Basic Rosary Today
```
[rosary_today]
```
Shows: "Today's Rosary: Joyful Mysteries" with description

### Rosary Today with Link to Rosary Page
```
[rosary_today link="/rosary" format="full" show_mysteries="yes"]
```
Shows: Full rosary info with link to /rosary#joyful (or appropriate anchor)

### Simple One-Line Rosary
```
[rosary_today format="simple" link="/rosary"]
```
Shows: "Today's Rosary: Joyful Mysteries" (linked)

### Link Only (Button Style)
```
[rosary_today format="link-only" link="/rosary"]
```
Shows: A styled button linking to the rosary page

### Weekly Rosary Schedule (Table)
```
[rosary_week link="/rosary" format="table"]
```
Shows: Table with all 7 days and their mysteries, today highlighted

### Weekly Rosary Schedule (List)
```
[rosary_week link="/rosary" format="list"]
```
Shows: List format of the weekly schedule

### Rosary Series Overview
```
[rosary_series link="/rosary"]
```
Shows: All four mystery series with descriptions and which days they're prayed

### Single Series Details
```
[rosary_series series="joyful" link="/rosary"]
```
Shows: Just the Joyful Mysteries card

### Full Rosary Page Content
```
[rosary_mysteries]
```
Shows: All four series with their five mysteries listed (great for a /rosary page)

Creates anchors: #joyful, #sorrowful, #glorious, #luminous

### Single Series Mysteries
```
[rosary_mysteries series="sorrowful"]
```
Shows: Just the Sorrowful Mysteries with all five listed

### Liturgical Day Info
```
[liturgical_day link_rosary="/rosary"]
```
Shows: Date, season, cycles, Liturgy of the Hours volume, and today's rosary

### Feast Day with Color
```
[feast_day_details]
```
Shows: Feast name with colored circle indicator (green, purple, red, white, etc.)

## Creating a Rosary Page

For a complete rosary page that links from other shortcodes:

```html
<h1>The Holy Rosary</h1>

<p>The Rosary is a Scripture-based prayer that begins with the Apostles' Creed.</p>

[rosary_today format="full" show_mysteries="no"]

<h2>The Four Sets of Mysteries</h2>

[rosary_mysteries]
```

This creates anchor links at #joyful, #sorrowful, #glorious, and #luminous that other shortcodes can link to.

## Sidebar/Widget Usage

For a sidebar widget showing today's rosary:
```
[rosary_today link="/rosary" format="simple"]
```

For a homepage rosary section:
```
[rosary_today link="/rosary" format="full"]
```

## Mini Shortcodes (Unstyled Content)

These shortcodes output just the content with minimal HTML - no backgrounds, buttons, headings or styling. Perfect for custom layouts where you want full control over the appearance.

### Feast Day Mini

| Shortcode | Description |
|-----------|-------------|
| `[feast_day_mini]` | Just the feast day info (name, color, rank) |

**Attributes:**
- `show` - What to display: `name`, `color`, `rank`, or `all` (default: all)
- `separator` - Separator between items (default: " \| ")
- `color_format` - How to show color: `text`, `hex`, `dot` (default: text)

**Examples:**
```
[feast_day_mini]
→ Saint John the Apostle | White | Feast

[feast_day_mini show="name"]
→ Saint John the Apostle

[feast_day_mini show="name,color" color_format="dot"]
→ Saint John the Apostle | ● White

[feast_day_mini show="color" color_format="hex"]
→ #FFFFFF
```

### Mass Readings Mini

| Shortcode | Description |
|-----------|-------------|
| `[mass_readings_mini]` | Just the reading references |

**Attributes:**
- `show` - What to display: `first`, `psalm`, `second`, `gospel`, or `all` (default: all shows first, psalm, gospel)
- `separator` - Separator between items (default: " \| ")
- `labels` - Show labels like "First Reading:" (default: yes)

**Examples:**
```
[mass_readings_mini]
→ First Reading: 1 John 1:1-4 | Psalm: Psalm 96(97) | Gospel: John 20:2-8

[mass_readings_mini labels="no"]
→ 1 John 1:1-4 | Psalm 96(97) | John 20:2-8

[mass_readings_mini show="gospel" labels="no"]
→ John 20:2-8

[mass_readings_mini show="first,psalm" separator=" • "]
→ First Reading: 1 John 1:1-4 • Psalm: Psalm 96(97)
```

### Liturgical Season Mini

| Shortcode | Description |
|-----------|-------------|
| `[liturgical_season_mini]` | Just the season info |

**Attributes:**
- `show` - What to display: `season`, `sunday_cycle`, `weekday_cycle`, `hours`, or `all` (default: all)
- `separator` - Separator between items (default: " \| ")
- `labels` - Show labels (default: yes)

**Examples:**
```
[liturgical_season_mini]
→ Season: Advent | Sunday Cycle: A | Weekday Cycle: Season | Hours: Volume I

[liturgical_season_mini show="season" labels="no"]
→ Advent

[liturgical_season_mini show="season,sunday_cycle" labels="yes"]
→ Season: Advent | Sunday Cycle: A
```

### Rosary Today Mini

| Shortcode | Description |
|-----------|-------------|
| `[rosary_today_mini]` | Just today's rosary mystery |

**Attributes:**
- `show` - What to display: `name`, `description`, `mysteries`, or `all` (default: name)
- `separator` - Separator between items (default: " - ")
- `link` - URL to link the mystery name to (optional)
- `mysteries_format` - How to show mysteries: `list`, `inline` (default: inline)

**Examples:**
```
[rosary_today_mini]
→ Luminous Mysteries

[rosary_today_mini link="/rosary"]
→ <a href="/rosary/#luminous">Luminous Mysteries</a>

[rosary_today_mini show="name,description"]
→ Luminous Mysteries - The Luminous Mysteries (Mysteries of Light) reflect on Christ's public ministry.

[rosary_today_mini show="mysteries" mysteries_format="inline"]
→ The Baptism in the Jordan, The Wedding at Cana, The Proclamation of the Kingdom, The Transfiguration, The Institution of the Eucharist
```

### Styling Mini Shortcodes

Each mini shortcode outputs spans with CSS classes you can target:

```css
/* Feast Day Mini */
.feast-day-mini { }
.feast-mini-name { }
.feast-mini-color { }
.feast-mini-color-dot { }
.feast-mini-rank { }

/* Mass Readings Mini */
.mass-readings-mini { }
.reading-mini-item { }
.reading-mini-label { }
.reading-mini-value { }

/* Liturgical Season Mini */
.liturgical-season-mini { }
.season-mini-item { }
.season-mini-label { }
.season-mini-value { }

/* Rosary Today Mini */
.rosary-today-mini { }
.rosary-mini-name { }
.rosary-mini-description { }
.rosary-mini-mysteries { }
.rosary-mini-mysteries-list { }
```

## Notes

- The liturgy.day API does **not** require an API key
- Data is cached for 24 hours
- If the API is unavailable, the system calculates rosary mysteries locally based on the current liturgical season
- The rosary schedule follows traditional Catholic practice, varying by liturgical season (Ordinary Time, Advent, Christmas, Lent, Easter)

## Liturgical Color Mapping

| Color | Hex | Seasons/Occasions |
|-------|-----|-------------------|
| Green | #008000 | Ordinary Time |
| White | #FFFFFF | Christmas, Easter, Saints |
| Red | #C41E3A | Pentecost, Martyrs |
| Violet/Purple | #800080 | Advent, Lent |
| Rose | #FF007F | Gaudete/Laetare Sundays |
| Gold | #FFD700 | Solemnities |
| Black | #000000 | All Souls, Funerals |

## Files Included

1. `class-parish-readings.php` - Complete updated PHP class
2. `shortcode-reference-update.php` - Updated shortcode documentation function
3. `front-css-additions.css` - Frontend styles for new shortcodes


# Parish Core - Hero Slider Feature

## Overview

A performant, responsive hero slider with **hybrid slide support** - allowing both manually created slides and dynamic slides that automatically pull content from your Parish Core data sources.

## Features

### Manual Slides
- Full control over image, title, subtitle, description, and CTA
- Custom text alignment (left, center, right)
- Perfect for welcome messages, announcements, and promotions

### Dynamic Slides
Auto-populated slides that update daily/weekly based on your parish data:

| Source | Description | Updates |
|--------|-------------|---------|
| **Latest Reflection** | Most recent reflection post | When new reflection is published |
| **Feast of the Day** | Today's liturgical feast/celebration | Daily |
| **Daily Readings** | Highlights today's Mass readings | Daily |
| **Liturgical Season** | Current season (Advent, Lent, etc.) | When season changes |
| **Today's Rosary** | Which mysteries to pray today | Daily |
| **Saint of the Day** | Today's saint | Daily |
| **Latest Newsletter** | Most recent newsletter | When new newsletter is published |
| **Next Event** | Upcoming parish event | As events change |

### Responsive Design
- Separate height settings for desktop, tablet, and mobile
- Touch/swipe support on mobile devices
- Graceful degradation on older browsers

### Performance
- Lightweight vanilla JavaScript (no jQuery dependency)
- CSS transitions (GPU accelerated)
- Lazy image preloading
- Intersection Observer for autoplay (pauses when not visible)
- Respects `prefers-reduced-motion` for accessibility

## Installation

### Step 1: Add New Files

Copy these files to your plugin:

| File | Location |
|------|----------|
| `class-parish-slider.php` | `includes/` |
| `parish-slider.js` | `assets/js/` |
| `slider.css` | `assets/css/` |
| `parish-core-admin-slider.js` | `assets/js/` |

### Step 2: Modify Existing Files

Follow the instructions in `slider-integration-guide.php` to update:

1. `parish-core.php` - Add slider to includes
2. `class-parish-admin-ui.php` - Add menu item and render method
3. `class-parish-assets.php` - Enqueue scripts and styles
4. `parish-core-admin-app.js` - Add slider route
5. `class-parish-rest-api.php` - Add API endpoints (use code from `slider-rest-api-additions.php`)
6. `class-parish-core.php` - Initialize slider instance

### Step 3: Add CSS

Append `admin-slider.css` contents to `assets/css/admin.css`

## Usage

### Shortcode

```html
[parish_slider]
```

With custom class:
```html
[parish_slider class="homepage-slider"]
```

### Gutenberg Block

Search for "Parish Slider" in the block inserter.

### Recommended Placement

Add to your homepage template or use in the Gutenberg editor on your front page.

## Admin Settings

Navigate to **Parish > Slider** to configure:

### Slider Settings
- **Enable Slider** - Turn the slider on/off
- **Autoplay** - Automatically advance slides
- **Autoplay Speed** - Time between slides (2-15 seconds)
- **Transition Speed** - Animation duration (300-2000ms)
- **Show Arrows** - Display prev/next buttons
- **Show Dots** - Display navigation dots
- **Pause on Hover** - Stop autoplay when mouse hovers

### Appearance
- **Heights** - Separate for desktop, tablet, mobile
- **Overlay Color** - Color that overlays the image
- **Overlay Opacity** - How transparent the overlay is
- **Gradient Overlay** - Fade from color to transparent

### Slides Management
- Drag to reorder slides
- Toggle slides on/off without deleting
- Mix manual and dynamic slides

## Creating Slides

### Manual Slide
1. Click "Add Slide"
2. Select "Manual Slide"
3. Upload background image
4. Enter title, subtitle, description
5. Add CTA button text and link
6. Choose text alignment
7. Save

### Dynamic Slide
1. Click "Add Slide"
2. Select "Dynamic Slide"
3. Choose data source (e.g., "Feast of the Day")
4. Optionally upload a fallback/custom image
5. Optionally override title/subtitle (leave blank for auto)
6. Customize CTA button if needed
7. Save

## Customization

### CSS Variables

Override in your theme:

```css
.parish-slider {
	--slider-height-desktop: 800px;
	--slider-height-tablet: 600px;
	--slider-height-mobile: 450px;
	--slider-overlay-color: #1a365d;
	--slider-overlay-opacity: 0.8;
	--slider-text-color: #ffffff;
	--slider-cta-bg: #c53030;
	--slider-cta-hover: #9b2c2c;
}
```

### Example: Seasonal Colors

```css
/* Advent - Purple */
.parish-slider.season-advent {
	--slider-overlay-color: #553c9a;
}

/* Christmas - Gold */
.parish-slider.season-christmas {
	--slider-overlay-color: #744210;
}

/* Lent - Purple */
.parish-slider.season-lent {
	--slider-overlay-color: #6b46c1;
}

/* Easter - White/Gold */
.parish-slider.season-easter {
	--slider-overlay-color: #2d3748;
}
```

## JavaScript Events

Listen for slide changes:

```javascript
document.querySelector('.parish-slider').addEventListener('slidechange', function(e) {
	console.log('Now showing slide:', e.detail.index);
});
```

## Accessibility

- Keyboard navigation (arrow keys)
- Focus indicators
- ARIA labels on buttons
- Respects `prefers-reduced-motion`
- Screen reader friendly

## Troubleshooting

### Slides not showing
1. Check that slider is enabled in settings
2. Verify at least one slide is enabled
3. For dynamic slides, ensure the data source has content

### Dynamic slide not updating
1. Try manually fetching the readings API
2. Check that the related CPT/feature is enabled
3. Clear any caching plugins

### Images not loading
1. Verify images are uploaded to Media Library
2. Check image URLs are accessible
3. Test with a manual slide first

## Files Reference

| File | Purpose |
|------|---------|
| `class-parish-slider.php` | Main PHP class - shortcode, rendering, dynamic sources |
| `parish-slider.js` | Frontend JavaScript - autoplay, touch, navigation |
| `slider.css` | Frontend styles - responsive, animations |
| `parish-core-admin-slider.js` | Admin React UI for managing slides |
| `admin-slider.css` | Admin page styles |
| `slider-rest-api-additions.php` | REST API endpoint code to add |
| `slider-integration-guide.php` | Code snippets for modifying existing files |

## Browser Support

- Chrome, Firefox, Safari, Edge (latest 2 versions)
- iOS Safari, Chrome for Android
- Graceful degradation for older browsers