<?php
/**
 * Church Schedule Block
 *
 * Dynamic block that renders the liturgical schedule for a church.
 * Uses Font Awesome icons and consistent styling with mass-schedule block.
 *
 * @package ParishCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Church Schedule Block class.
 */
class Parish_Church_Schedule_Block {

	/**
	 * Register the block with WordPress.
	 *
	 * @return void
	 */
	public static function register(): void {
		register_block_type(
			'parish/church-schedule',
			array(
				'api_version'     => 3,
				'editor_script'   => 'parish-core-editor-blocks',
				'render_callback' => array( __CLASS__, 'render' ),
				'uses_context'    => array( 'postType', 'postId' ),
				'attributes'      => array(
					'format'         => array(
						'type'    => 'string',
						'default' => 'list',
					),
					'eventTypes'     => array(
						'type'    => 'array',
						'default' => array( 'mass', 'confession' ),
						'items'   => array( 'type' => 'string' ),
					),
					'showFeastDay'   => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'days'           => array(
						'type'    => 'integer',
						'default' => 7,
					),
					'showIcon'       => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'showLivestream' => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'groupByDay'     => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'showAllDays'    => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'iconColor'      => array(
						'type'    => 'string',
						'default' => '',
					),
					'timeColor'      => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'supports'        => array(
					'html'     => false,
					'align'    => array( 'wide', 'full' ),
					'spacing'  => array(
						'margin'  => true,
						'padding' => true,
					),
				),
			)
		);
	}

	/**
	 * Render the block on the frontend.
	 *
	 * @param array    $attributes Block attributes.
	 * @param string   $content    Block content.
	 * @param WP_Block $block      Block instance.
	 * @return string Rendered HTML.
	 */
	public static function render( array $attributes, string $content, WP_Block $block ): string {
		$post_id = $block->context['postId'] ?? get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		// Only render on church posts.
		$post_type = get_post_type( $post_id );
		if ( 'parish_church' !== $post_type ) {
			return '';
		}

		// Check if church has schedule_display set to 'static' (legacy mode).
		$display_mode = get_post_meta( $post_id, 'parish_schedule_display', true );
		if ( 'static' === $display_mode ) {
			return self::render_static_schedule( $post_id, $attributes );
		}

		$church_id       = (int) $post_id;
		$show_icon       = (bool) ( $attributes['showIcon'] ?? true );
		$show_livestream = (bool) ( $attributes['showLivestream'] ?? true );
		$show_all_days   = (bool) ( $attributes['showAllDays'] ?? true );
		$event_types     = $attributes['eventTypes'] ?? array( 'mass', 'confession' );
		$icon_color      = sanitize_hex_color( $attributes['iconColor'] ?? '' ) ?: 'var(--wp--preset--color--accent,#609fae)';
		$time_color      = sanitize_hex_color( $attributes['timeColor'] ?? '' ) ?: 'var(--wp--preset--color--accent,#609fae)';

		// Get all active Mass Time posts for this church.
		$meta_query = array(
			'relation' => 'AND',
			array(
				'key'     => 'parish_mass_time_is_active',
				'value'   => '1',
				'compare' => '=',
			),
			array(
				'relation' => 'OR',
				array(
					'key'     => 'parish_mass_time_church_id',
					'value'   => $church_id,
					'compare' => '=',
				),
				array(
					'key'     => 'parish_mass_time_church_id',
					'value'   => '0',
					'compare' => '=',
				),
			),
		);

		// Filter by event types if specified.
		if ( ! empty( $event_types ) && is_array( $event_types ) ) {
			$meta_query[] = array(
				'key'     => 'parish_mass_time_liturgical_type',
				'value'   => $event_types,
				'compare' => 'IN',
			);
		}

		$mass_time_posts = get_posts( array(
			'post_type'      => 'parish_mass_time',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'meta_query'     => $meta_query,
		) );

		// Day order for weekly schedule.
		$day_order = array( 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday' );

		// Categorize posts by day.
		$weekly_data    = array();
		$special_events = array();

		foreach ( $mass_time_posts as $mt_post ) {
			$is_recurring     = get_post_meta( $mt_post->ID, 'parish_mass_time_is_recurring', true );
			$is_special       = get_post_meta( $mt_post->ID, 'parish_mass_time_is_special_event', true );
			$recurrence       = get_post_meta( $mt_post->ID, 'parish_mass_time_recurrence', true );
			$start_datetime   = get_post_meta( $mt_post->ID, 'parish_mass_time_start_datetime', true );
			$notes            = get_post_meta( $mt_post->ID, 'parish_mass_time_notes', true );
			$side_note        = get_post_meta( $mt_post->ID, 'parish_mass_time_side_note', true );
			$is_livestreamed  = get_post_meta( $mt_post->ID, 'parish_mass_time_is_livestreamed', true );
			$liturgical_type  = get_post_meta( $mt_post->ID, 'parish_mass_time_liturgical_type', true );

			$time = self::format_time( $start_datetime );

			$event_data = array(
				'id'              => $mt_post->ID,
				'title'           => $mt_post->post_title,
				'time'            => $time,
				'notes'           => $notes,
				'side_note'       => $side_note,
				'is_livestreamed' => $is_livestreamed,
				'type'            => $liturgical_type,
			);

			if ( $is_special ) {
				$special_events[] = $event_data;
			} elseif ( $is_recurring && is_array( $recurrence ) ) {
				$rec_type = $recurrence['type'] ?? 'weekly';
				$rec_days = $recurrence['days'] ?? array();

				if ( ( $rec_type === 'weekly' || $rec_type === 'biweekly' ) && ! empty( $rec_days ) ) {
					foreach ( $rec_days as $day ) {
						if ( ! isset( $weekly_data[ $day ] ) ) {
							$weekly_data[ $day ] = array();
						}
						$weekly_data[ $day ][] = $event_data;
					}
				} elseif ( $rec_type === 'daily' ) {
					foreach ( $day_order as $day ) {
						if ( ! isset( $weekly_data[ $day ] ) ) {
							$weekly_data[ $day ] = array();
						}
						$weekly_data[ $day ][] = $event_data;
					}
				} elseif ( $rec_type === 'monthly_ordinal' ) {
					$ordinal                = $recurrence['ordinal'] ?? 'first';
					$ordinal_day            = $recurrence['ordinal_day'] ?? '';
					$event_data['title']    = ucfirst( $ordinal ) . ' ' . $ordinal_day;
					$special_events[]       = $event_data;
				} else {
					$special_events[] = $event_data;
				}
			} else {
				// Fallback: try to extract day of week from start_datetime.
				$day_from_datetime = self::get_day_from_datetime( $start_datetime );
				if ( $day_from_datetime && in_array( $day_from_datetime, $day_order, true ) ) {
					if ( ! isset( $weekly_data[ $day_from_datetime ] ) ) {
						$weekly_data[ $day_from_datetime ] = array();
					}
					$weekly_data[ $day_from_datetime ][] = $event_data;
				} elseif ( ! empty( $event_data['title'] ) ) {
					$special_events[] = $event_data;
				}
			}
		}

		// Sort events within each day by time.
		foreach ( $weekly_data as $day => $events ) {
			usort( $weekly_data[ $day ], function ( $a, $b ) {
				return strcmp( $a['time'], $b['time'] );
			} );
		}

		// Build HTML output.
		$html = '<div class="parish-church-schedule-rows">';

		// Weekly schedule section.
		foreach ( $day_order as $day ) {
			$events = $weekly_data[ $day ] ?? array();

			if ( empty( $events ) && ! $show_all_days ) {
				continue;
			}

			$html .= self::render_schedule_row_html( $day, $events, $show_icon, $show_livestream, $icon_color, $time_color );
		}

		// Special events section.
		if ( ! empty( $special_events ) ) {
			$html .= '<div class="parish-church-schedule-divider"></div>';
			foreach ( $special_events as $event ) {
				$html .= self::render_schedule_row_html(
					$event['title'],
					array( $event ),
					$show_icon,
					$show_livestream,
					$icon_color,
					$time_color
				);
			}
		}

		$html .= '</div>';

		if ( empty( $weekly_data ) && empty( $special_events ) ) {
			if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
				return sprintf(
					'<div class="parish-church-schedule-placeholder">%s</div>',
					esc_html__( 'No schedule found for this church.', 'parish-core' )
				);
			}
			return '';
		}

		// Get block wrapper attributes.
		$wrapper_attributes = get_block_wrapper_attributes(
			array(
				'class' => 'parish-church-schedule-block',
			)
		);

		return sprintf(
			'<div %s>%s</div>',
			$wrapper_attributes,
			$html
		);
	}

	/**
	 * Render a single schedule row as HTML.
	 *
	 * @param string $label          Day name or event title.
	 * @param array  $events         Events for this row.
	 * @param bool   $show_icon      Whether to show the clock icon.
	 * @param bool   $show_livestream Whether to show livestream indicators.
	 * @param string $icon_color     Color for icons.
	 * @param string $time_color     Color for times.
	 * @return string HTML output.
	 */
	private static function render_schedule_row_html( string $label, array $events, bool $show_icon, bool $show_livestream, string $icon_color, string $time_color ): string {
		// Use inline styles to force the layout.
		$row_style   = 'display:flex;flex-direction:row;align-items:center;gap:0.75em;padding:0.35em 0;border-bottom:1px solid rgba(0,0,0,0.05);';
		$icon_style  = 'flex:0 0 auto;width:1.2em;display:inline-flex;align-items:center;justify-content:center;';
		$day_style   = 'flex:0 0 120px;font-weight:500;';
		$times_style = 'flex:1 1 auto;display:inline-flex;flex-wrap:wrap;align-items:center;gap:0.25em;';

		$html = sprintf( '<div class="parish-church-schedule-row" style="%s">', $row_style );

		// Clock icon (optional).
		if ( $show_icon ) {
			$html .= sprintf(
				'<div class="parish-church-schedule-icon" style="%s"><i class="fa-regular fa-clock" style="color:%s;font-size:1em;"></i></div>',
				$icon_style,
				esc_attr( $icon_color )
			);
		}

		// Day name.
		$html .= sprintf(
			'<div class="parish-church-schedule-day" style="%s">%s</div>',
			$day_style,
			esc_html( $label )
		);

		// Times.
		$html .= sprintf( '<div class="parish-church-schedule-times" style="%s">', $times_style );

		if ( empty( $events ) ) {
			$html .= '<span class="parish-church-schedule-no-event" style="font-style:italic;opacity:0.5;">' . esc_html__( 'No events', 'parish-core' ) . '</span>';
		} else {
			$times_parts = array();

			foreach ( $events as $event ) {
				$time_html = sprintf(
					'<span class="parish-church-schedule-time" style="color:%s;font-weight:600;">%s</span>',
					esc_attr( $time_color ),
					esc_html( $event['time'] )
				);

				if ( ! empty( $event['notes'] ) ) {
					$time_html .= ' <span class="parish-church-schedule-note" style="font-size:0.9em;opacity:0.7;">(' . esc_html( wp_strip_all_tags( $event['notes'] ) ) . ')</span>';
				}

				// Add livestream icon right after this time if applicable.
				if ( $show_livestream && ! empty( $event['is_livestreamed'] ) ) {
					$time_html .= sprintf(
						' <i class="fa-solid fa-video" style="color:%s;font-size:0.9em;" aria-label="%s"></i>',
						esc_attr( $icon_color ),
						esc_attr__( 'Livestreamed', 'parish-core' )
					);
				}

				$times_parts[] = $time_html;
			}

			$html .= implode( '<span class="parish-church-schedule-sep" style="opacity:0.5;">, </span>', $times_parts );
		}

		$html .= '</div>';

		// Side note.
		$side_note = '';
		foreach ( $events as $event ) {
			if ( ! empty( $event['side_note'] ) ) {
				$side_note = $event['side_note'];
				break;
			}
		}
		if ( $side_note ) {
			$html .= '<div class="parish-church-schedule-sidenote" style="flex:0 0 auto;font-size:0.85em;font-style:italic;opacity:0.6;margin-left:auto;text-align:right;">' . esc_html( $side_note ) . '</div>';
		}

		$html .= '</div>';

		return $html;
	}

	/**
	 * Render static/legacy schedule from meta fields.
	 *
	 * @param int   $post_id    Church post ID.
	 * @param array $attributes Block attributes.
	 * @return string Rendered HTML.
	 */
	private static function render_static_schedule( int $post_id, array $attributes ): string {
		$mass_times       = get_post_meta( $post_id, 'parish_mass_times', true );
		$confession_times = get_post_meta( $post_id, 'parish_confession_times', true );
		$icon_color       = sanitize_hex_color( $attributes['iconColor'] ?? '' ) ?: 'var(--wp--preset--color--accent,#609fae)';

		if ( empty( $mass_times ) && empty( $confession_times ) ) {
			return '';
		}

		$wrapper_attributes = get_block_wrapper_attributes(
			array( 'class' => 'parish-church-schedule-block parish-church-schedule-block--static' )
		);

		$output = sprintf( '<div %s>', $wrapper_attributes );

		if ( ! empty( $mass_times ) ) {
			$output .= '<div class="parish-church-schedule-section">';
			$output .= sprintf(
				'<h3 class="parish-church-schedule-section-title"><i class="fa-solid fa-church" style="color:%s;margin-right:0.5em;"></i>%s</h3>',
				esc_attr( $icon_color ),
				esc_html__( 'Mass Times', 'parish-core' )
			);
			$output .= '<div class="parish-church-schedule-section-content">' . wp_kses_post( nl2br( $mass_times ) ) . '</div>';
			$output .= '</div>';
		}

		if ( ! empty( $confession_times ) ) {
			$output .= '<div class="parish-church-schedule-section">';
			$output .= sprintf(
				'<h3 class="parish-church-schedule-section-title"><i class="fa-solid fa-hands-praying" style="color:%s;margin-right:0.5em;"></i>%s</h3>',
				esc_attr( $icon_color ),
				esc_html__( 'Confession Times', 'parish-core' )
			);
			$output .= '<div class="parish-church-schedule-section-content">' . wp_kses_post( nl2br( $confession_times ) ) . '</div>';
			$output .= '</div>';
		}

		$output .= '</div>';

		return $output;
	}

	/**
	 * Format time from various input formats.
	 *
	 * @param string $datetime DateTime or time string.
	 * @return string Formatted time.
	 */
	private static function format_time( string $datetime ): string {
		if ( empty( $datetime ) ) {
			return '';
		}

		// Handle ISO 8601 format (2026-01-11T10:00).
		if ( strpos( $datetime, 'T' ) !== false ) {
			$parts = explode( 'T', $datetime );
			$time  = $parts[1] ?? '';
			if ( strlen( $time ) > 5 ) {
				$time = substr( $time, 0, 5 );
			}
		} elseif ( strpos( $datetime, ' ' ) !== false ) {
			$parts = explode( ' ', $datetime );
			$time  = $parts[1] ?? '';
			if ( strlen( $time ) > 5 ) {
				$time = substr( $time, 0, 5 );
			}
		} else {
			$time = $datetime;
		}

		$timestamp = strtotime( "2000-01-01 $time" );
		if ( $timestamp === false ) {
			return $time;
		}

		return gmdate( 'g:i A', $timestamp );
	}

	/**
	 * Extract day of week from a datetime string.
	 *
	 * @param string $datetime DateTime string (ISO 8601 or other format).
	 * @return string|null Day name (e.g., "Monday") or null if parsing fails.
	 */
	private static function get_day_from_datetime( string $datetime ): ?string {
		if ( empty( $datetime ) ) {
			return null;
		}

		$timestamp = strtotime( $datetime );
		if ( $timestamp === false ) {
			return null;
		}

		return gmdate( 'l', $timestamp );
	}
}
