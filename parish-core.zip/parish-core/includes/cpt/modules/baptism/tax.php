<?php
/**
 * Taxonomies: Baptism (none for now)
 *
 * @package ParishCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Intentionally empty.
// Return nothing / do nothing.
